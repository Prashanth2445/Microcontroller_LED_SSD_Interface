/*
 * File:   main.c
 * Author: predd
 *
 * Created on 3 March, 2026, 8:50 AM
 */


#include <xc.h>
#include "digital_keypad.h"

void main(void) 
{
    int key;
    int prev = 0x0F;
    unsigned long delay = 0;
    int i=0;
    //Pin Configaration 
    TRISC = TRISC | INPUT_PINS;
    TRISB = 0x00;
    PORTB = 0x00;
    while(1)
    {
        key = read_digital_keypad(STATE_CHANGE);
        
        if(key != INPUT_PINS)
        {
            prev=key;
            i=0;
            PORTB= 0x00;
        }
        if(prev == SWITCH1)
        {
            if(delay++ == 20000)
            {
                delay = 0;
            
                if (i < 8)
                {
                    PORTB = ((PORTB << 1)| 1 );
                }
                else if (i < 16 )
                {
                    PORTB = (PORTB << 1);
                }
                else if (i < 24 )
                {
                    PORTB = ((PORTB >> 1) | 0x80);
                }
                else if( i < 32 )
                {
                    PORTB = (PORTB >> 1);
                }
                else
                {
                    i = 0;
                    PORTB = 0x00;
                }
                i++;
            }
        }
        else if (prev == SWITCH2)
        {
            if(delay++ == 20000)
            {
                delay = 0;
            
                if (i < 8)
                {
                    PORTB = ((PORTB << 1)| 1 );
                }
                else if (i < 16 )
                {
                    PORTB = (PORTB << 1);
                }
                else
                {
                    i=0;
                    PORTB = 0x00;
                }
                i++;
            }
        }
        else if (prev == SWITCH3)
        {
            if(i == 0)
            {
                PORTB = 0xAA;
                i = 1;
            }
            if(delay++ == 20000)
            {
                delay = 0;
                PORTB = ~PORTB;
            }
        }
        else if (prev == SWITCH4)
        {
            if(i==0)
            {
                PORTB = 0x0F;
                i=1;
            }
            if(delay++ == 20000)
            {
                delay = 0;
                PORTB = ~PORTB;
            }   
        }
    }
    return;
}


unsigned char read_digital_keypad(unsigned char detection_type)
{
	static unsigned char once = 1;

	if (detection_type == STATE_CHANGE)
	{
		if (((KEY_PORT & INPUT_PINS) != ALL_RELEASED) && once)
		{
			once = 0;

			return (KEY_PORT & INPUT_PINS);
		}
		else if ((KEY_PORT & INPUT_PINS) == ALL_RELEASED)
		{
			once = 1;
		}
	}
	else if (detection_type == LEVEL)
	{
		return (KEY_PORT & INPUT_PINS);
	}

	return 0x0F;
}