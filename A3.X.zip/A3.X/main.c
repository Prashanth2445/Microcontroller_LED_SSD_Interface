/*
 * File:   main.c
 * Author: predd
 *
 * Created on 5 March, 2026, 8:20 AM
 */

#include <xc.h>

#define ZERO 0xE7      // 0
#define ONE 0x21      // 1
#define TWO 0xCB      // 2
#define THREE 0x6B    // 3
#define FOUR 0x2D    // 4
#define FIVE 0x6E    // 5
#define SIX 0xEE     // 6
#define SEVEN 0x23   // 7
#define EIGHT 0xEF   // 8
#define NINE 0x6F    // 9
#define BLANK 0x00   // "  "

char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, BLANK, BLANK };

char ssd[4];

void display(char *);

void main(void) 
{
    int i=0;
    TRISD = 0x00;
    TRISA = TRISA & 0xf0;
    PORTA = PORTA & 0xf0;
    
    while(1)
    {
        ssd[0]=digit[i%12];
        ssd[1]=digit[(i+1)%12];
        ssd[2]=digit[(i+2)%12];
        ssd[3]=digit[(i+3)%12];
        i++;
        if (i == 12)
        {
            i=0;
        }
        for(int k=100;k--;)
        {
            display(ssd);
        }
    }
    return;
}
void display(char ssd[])
{
    for(int i=0;i<4;i++)
    {
        PORTD = ssd[i];
        PORTA = (PORTA & 0) | (1 << i);
        for(int delay=1000;delay--;);
    }
    return;
}